function [project_train_img, k_eig_vec, m] = train_PCA(train_matrix,k)

%% Arguments %%
% train_matrix : training image matrix with dimension of N*d 
%               (N is the number of training images and d is the dimension of one images.)
% k: number of PCs

%% Your code here %%
% write code to find eigen vectors 'eigen_face'.




%% display 3 biggest eigen vectors
for i = 1:3
    subplot(1,3,i)
    imagesc(reshape(k_eig_vec(:,i), 64, 64));
end

end
