function [recognized_img] = identify(projectimg,projtestimg)

%% Arguments %%
% project_train_img : training matrix represented by k PCs
% project_test_img : test matrix represented by k PCs

%% Your code here %%
% Hint: Use Euclidean distance to measure similarity.

end
