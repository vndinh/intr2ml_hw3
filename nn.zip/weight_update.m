function net = weight_update(net, net_update, l_rate)
%% Your code here %%

end