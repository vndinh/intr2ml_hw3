function net_update = back_propagation(net, data_output)
%% Your code here %%

end