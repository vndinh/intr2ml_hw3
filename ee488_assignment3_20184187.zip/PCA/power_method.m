function [v,d] = power_method(A)
% for finding the largest eigen value by power method
 
% initial guess for X..?
 
% default guess is [ 1 1 .... 1]'

[mA,nA] = size(A);
X0 = ones(mA,1);
 
%allowed error in final answer
t = 0.0001;
tol = t*ones(mA,1);

% initialing k and X
k = 1;
X(:,1) = X0;

%initial error assumption
err = 1000000000*rand(mA,1);

% loop starts
while sum(abs(err) >= tol) ~= 0
    X(:,k+1) = A*X(:,k); %POWER METHOD formula
    % normalizing the obtained vector 
    [v,i] = max(abs(A*X(:,k+1)));
    E = X(:,k+1);
    e(k,1) = E(i,1);
    X(:,k+1) = X(:,k+1) / e(k,1);
    err = X(:,k+1) - X(:,k);% finding error
    k = k + 1;  
end

v = X;
for i = 1:k
   v(:,i) = X(:,i)/norm(X(:,i)); 
end

d = e;
end