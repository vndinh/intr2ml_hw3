function [project_train_img, k_eig_vec, m] = train_PCA(train_matrix,k)

%% Arguments %%
% train_matrix : training image matrix with dimension of N*d 
%               (N is the number of training images and d is the dimension of one images.)
% k: number of PCs

%% Your code here %%
% write code to find eigen vectors 'eigen_face'.
[N,d] = size(train_matrix);

% Mean of all images
m = sum(train_matrix) / N;

% Coveriance matrix
X = train_matrix - repmat(m,N,1);
S = zeros(d,d);
for i = 1:N
   S = S + X(i,:)' * X(i,:); 
end
S = S / N;

% Calculate eigenvectors of the coveriance matrix
[eig_vec, ~] = eig(S);

% Choose k eigenvectors corresponding k biggest eigenvalues
k_eig_vec = eig_vec(:,(4096-k+1):4096);

% Projection training images in the subspace created by k chosen
% eigenvectors
project_train_img = X * k_eig_vec;

%% display 5 biggest eigen vectors
for i = 1:5
    subplot(2,3,i)
    imagesc(reshape(k_eig_vec(:,i), 64, 64));
end

end
