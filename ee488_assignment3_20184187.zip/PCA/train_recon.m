function [recon_error]=train_recon(train_matrix,project_train_img,k_eig_vec,m)

%% Arguments %%
% train_matrix : training data matrix with dimension of N*d 
%               (N is the number of training images and d is the dimension of one images.)
% project_train_img : training matrix represented by k PCs
% k_eig_vec : k biggest eigen vectors.
% m: mean from training matrix.
 
%% Your code here %%
% write code to find reconstructed image 'recon_img' and reconstruction
% error.
N = size(train_matrix,1);

% Reconstruct training images from their projection
recon_img = project_train_img * k_eig_vec' + repmat(m,N,1);

% Calculate mean square error of the reconstructed images
D = train_matrix - recon_img;
recon_error = 0;
for i = 1:N
    recon_error = recon_error + (norm(D(i,:)))^2;
end
recon_error = recon_error / N;

%% save reconstructed images in the folder 'train_reconstruction'
face = zeros(64,64);
mkdir('train_reconstruction')
for i=1:size(recon_img,1)
    fname = sprintf('train_reconstruction/%dres.jpg',i);
    face(:) = recon_img(i,:);
    imwrite(uint8(face), fname);
end
end

