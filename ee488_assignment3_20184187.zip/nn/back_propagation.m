function net_update = back_propagation(net,data_output)
%% Your code here %%
D1 = net.layer{net.layer_num,1} - data_output;

D2 = cell(net.layer_num,1);
net_update = cell(net.layer_num,1);

% Chain rule
for index_layer = 1:net.layer_num
    D2{index_layer,1} = zeros(net.num_neuron(index_layer,1),1);
    D2{index_layer,1} = net.layer{index_layer,1}.*(1-net.layer{index_layer,1});
    net_update{index_layer,1} = zeros(size(net.weight{index_layer,1}));
end

for index_layer = 2:net.layer_num
   if index_layer == net.layer_num
       net_update{index_layer,1} = (D1.*D2{index_layer,1})*(net.layer{index_layer-1,1})';
   else
       net_update{index_layer,1} = (((D1.*D2{index_layer+1,1})'*net.weight{index_layer+1,1})'.*D2{index_layer,1})*(net.layer{index_layer-1,1})';
   end
end

end